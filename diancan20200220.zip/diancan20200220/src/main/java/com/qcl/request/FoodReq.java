package com.qcl.request;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 */
@Data
public class FoodReq {
    private Integer foodId;
    @NotEmpty(message = "菜品名必填")
    private String foodName;
    @NotNull(message = "菜品价格必填")
    private BigDecimal foodPrice;
    private Integer foodStock;
    private String foodDesc;
    @NotEmpty(message = "菜品图必填")
    private String foodIcon;

    private Integer leimuType;

    public Integer getFoodId() {
        return foodId;
    }

    public void setFoodId(Integer foodId) {
        this.foodId = foodId;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public BigDecimal getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(BigDecimal foodPrice) {
        this.foodPrice = foodPrice;
    }

    public Integer getFoodStock() {
        return foodStock;
    }

    public void setFoodStock(Integer foodStock) {
        this.foodStock = foodStock;
    }

    public String getFoodDesc() {
        return foodDesc;
    }

    public void setFoodDesc(String foodDesc) {
        this.foodDesc = foodDesc;
    }

    public String getFoodIcon() {
        return foodIcon;
    }

    public void setFoodIcon(String foodIcon) {
        this.foodIcon = foodIcon;
    }

    public Integer getLeimuType() {
        return leimuType;
    }

    public void setLeimuType(Integer leimuType) {
        this.leimuType = leimuType;
    }
}
