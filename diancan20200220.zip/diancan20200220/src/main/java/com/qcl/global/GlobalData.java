package com.qcl.global;

/**
 *
 */
public class GlobalData {
    public static int ADMIN_ID = -1;
}
