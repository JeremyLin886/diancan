package com.qcl.global;

/**
 *
 * 一些全局的常量
 * 用来管理cookie
 */
public interface GlobalConst {
    String COOKIE_TOKEN = "bianchengxiaoshitou";//用来管理Cookie的key

}
