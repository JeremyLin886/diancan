package com.qcl.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 商品(包含类目)
 *
 */
@Data
public class LeimuVO {

    @JsonProperty("name")
    private String leimuName;

    @JsonProperty("type")
    private Integer leimuType;

    @JsonProperty("foods")
    private List<FoodRes> foodResList;

    public String getLeimuName() {
        return leimuName;
    }

    public void setLeimuName(String leimuName) {
        this.leimuName = leimuName;
    }

    public Integer getLeimuType() {
        return leimuType;
    }

    public void setLeimuType(Integer leimuType) {
        this.leimuType = leimuType;
    }

    public List<FoodRes> getFoodResList() {
        return foodResList;
    }

    public void setFoodResList(List<FoodRes> foodResList) {
        this.foodResList = foodResList;
    }
}
