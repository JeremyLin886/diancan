package com.qcl.api;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

import com.qcl.meiju.FoodStatusEnum;
import lombok.Data;

/**
 * 返回给小程序的菜品页
 *
 */
@Data
public class FoodRes {
    @JsonProperty("id")
    private Integer foodId;

    @JsonProperty("name")
    private String foodName;

    @JsonProperty("price")
    private BigDecimal foodPrice;
    @JsonProperty("stock")
    private Integer foodStock;//库存

    @JsonProperty("desc")
    private String foodDesc;

    @JsonProperty("icon")
    private String foodIcon;

    public Integer getFoodId() {
        return foodId;
    }

    public void setFoodId(Integer foodId) {
        this.foodId = foodId;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public BigDecimal getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(BigDecimal foodPrice) {
        this.foodPrice = foodPrice;
    }

    public Integer getFoodStock() {
        return foodStock;
    }

    public void setFoodStock(Integer foodStock) {
        this.foodStock = foodStock;
    }

    public String getFoodDesc() {
        return foodDesc;
    }

    public void setFoodDesc(String foodDesc) {
        this.foodDesc = foodDesc;
    }

    public String getFoodIcon() {
        return foodIcon;
    }

    public void setFoodIcon(String foodIcon) {
        this.foodIcon = foodIcon;
    }
}
